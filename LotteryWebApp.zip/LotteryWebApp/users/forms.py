from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, EmailField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError
from flask_wtf import RecaptchaField
import re
def character_check(form, field):
    excluded_chars = "*?!'^+%&/()=}][{$#@<>"
    for char in field.data:
        if char in excluded_chars:
            raise ValidationError(f"Character {char}is not allowed")
def validate_pass(form, field):
    p = re.compile("(?=.*\d)(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])(?=.*[*?!'^+%&/()=}{$#@<>])")
    if not p.match(field.data):
        raise ValidationError("Password must contain atleast 6-12 Characters and 1 digit, 1 lowercase, 1 uppercase, 1 special character")
def validate_phoneno(form, field):
    p = re.compile("(\d{4})-(\d{3})-(\d{4})")
    if not p.match(field.data):
        raise ValidationError("Phone number must be in XXXX-XXX-XXXX from")

class RegisterForm(FlaskForm):
    email = EmailField('Email',
                        validators=[DataRequired(), Email()])
    firstname = StringField('Firstname',validators=[DataRequired(),character_check])
    lastname = StringField('Lastname',validators=[DataRequired(),character_check])
    phone = StringField('Phone',validators=[DataRequired(),validate_phoneno])
    password = PasswordField('Password',
                             validators=[DataRequired(), validate_pass])
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(),EqualTo('password')])
    submit = SubmitField('Sign up')

class LoginForm(FlaskForm):
    email = StringField('Email',
                           validators=[DataRequired(), Email()])
    password = PasswordField('Password',
                             validators=[DataRequired()])
    pin = StringField(validators=[DataRequired()])
    submit = SubmitField()
    recaptcha = RecaptchaField()